__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/52b5baf14a13cf95.js",
  "static/chunks/turbopack-b58cf2802592e597.js"
])
