__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/52b5baf14a13cf95.js",
  "static/chunks/turbopack-d0fb0e1b3f9bf314.js"
])
